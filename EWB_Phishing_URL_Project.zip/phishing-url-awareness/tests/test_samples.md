# Test Results\n\nAll five required sample strings were checked using `inspect_url()`.\n\n| # | Input | Expected result | Actual result | Status |\n|---|---|---|---|---|\n| 1 | `https://www.example.com/login` | No listed signs; not proof of safety | No listed warning signs found. This does NOT prove safety. | **PASS** |\n| 2 | `http://192.0.2.10/account` | IP address and HTTP | Uses an IP address instead of a familiar domain.; Uses HTTP. HTTPS alone does not prove trust. | **PASS** |\n| 3 | `http://example.com@sample.invalid/login` | @ symbol and HTTP | Contains an @ symbol; inspect carefully.; Uses HTTP. HTTPS alone does not prove trust. | **PASS** |\n| 4 | `https://a.b.c.d.e.example.invalid/path` | Many hostname segments | Contains many hostname segments/subdomains. | **PASS** |\n| 5 | `https://xn--example.invalid/` | Punycode-style hostname | Contains a punycode-style hostname. | **PASS** |\n
## Additional checks

| Input | Expected behaviour | Status |
|---|---|---|
| Empty input | Friendly message; no crash | PASS |
| `http://[bad` | Malformed URL message; no crash | PASS |
| `www.example.com` | Defaults to HTTP and flags HTTP | PASS |
| `q` at prompt | Exits with goodbye message | PASS |

This tool only examines text. It does not prove a URL is safe, visit websites, or use a reputation service.
