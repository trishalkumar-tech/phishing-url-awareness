# EWB Phishing URL Awareness Checker

## Overview
This beginner-friendly command-line Python program checks URL text for visible phishing warning signs. It never opens or submits a URL.

## Warning signs checked
1. `@` symbol in the URL text.
2. URL longer than 100 characters.
3. Valid IPv4 address used as the hostname.
4. Hostname containing five or more dot-separated labels.
5. `xn--` punycode marker in the hostname.
6. HTTP scheme.

## Requirements
- Python 3.10 or later.
- No third-party packages.

## Run
From this folder, run:

```bash
python phishing_checker.py
```

On macOS/Linux, you can use `python3 phishing_checker.py`. Enter a URL at the prompt. Type `q`, `quit`, or `exit` to stop.

## Example
```text
Enter a sample URL to inspect (or q to quit): http://192.0.2.10/account

Result:
- Uses an IP address instead of a familiar domain.
- Uses HTTP. HTTPS alone does not prove trust.

REVIEW CAREFULLY: 2 warning sign(s) found.
```

## Testing
Five workbook sample URLs and additional edge cases are documented in [`tests/test_samples.md`](tests/test_samples.md). All five required sample checks pass.

## Improvements
- Repeat-and-quit loop supports multiple checks in one session.
- Friendly handling for empty and malformed inputs.
- Warning summary counts detected signs.

## Screenshots
The `screenshots/` folder contains seven terminal-style example/evidence images:

1. `sample_run.png` — sample run detecting an IP address and HTTP.
2. `test_results.png` — five workbook sample test results.
3. `screenshot_03_normal_url.png` — normal HTTPS example with no listed signs.
4. `screenshot_04_at_symbol_warning.png` — `@` symbol warning.
5. `screenshot_05_long_url_warning.png` — unusually long URL warning.
6. `screenshot_06_punycode_warning.png` — punycode marker warning.
7. `screenshot_07_quit_command.png` — exiting the program with `q`.

These are generated terminal-style illustrations of representative program output, not photographs captured from a live desktop session. Capture genuine screenshots from your own computer if your course requires live execution evidence.

## Limitations and safe use
This is an educational awareness tool, not a security verdict. No warning signs found does NOT mean a URL is safe. Some harmless URLs can trigger warnings, and dangerous URLs may not trigger these checks. The program does not scan malware, visit sites, or query online reputation services. Never enter credentials on an unexpected link.

## Author
Student mini project | EWB Courses | Cybersecurity
