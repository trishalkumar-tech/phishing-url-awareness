"""Educational URL text checker. It does not visit or submit URLs."""
import re
from urllib.parse import urlparse

def inspect_url(raw_url):
    url = raw_url.strip()
    if not url:
        return ["No URL entered."]
    candidate = url if "://" in url else "http://" + url
    try:
        parsed = urlparse(candidate)
        host = (parsed.hostname or "").lower()
    except ValueError:
        return ["This text is not a valid URL format."]
    if not host:
        return ["Could not identify a hostname."]

    findings = []
    if "@" in candidate:
        findings.append("Contains an @ symbol; inspect carefully.")
    if len(url) > 100:
        findings.append("Unusually long URL (over 100 characters).")
    if re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", host):
        if all(0 <= int(x) <= 255 for x in host.split(".")):
            findings.append("Uses an IP address instead of a familiar domain.")
    if len([x for x in host.split(".") if x]) >= 5:
        findings.append("Contains many hostname segments/subdomains.")
    if "xn--" in host:
        findings.append("Contains a punycode-style hostname.")
    if parsed.scheme.lower() == "http":
        findings.append("Uses HTTP. HTTPS alone does not prove trust.")
    if not findings:
        findings.append("No listed warning signs found. This does NOT prove safety.")
    return findings

def main():
    print("EWB Phishing URL Awareness Checker")
    print("Text checks only - this program does not open URLs.")
    while True:
        try:
            raw = input("\nEnter a sample URL to inspect (or q to quit): ")
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye! Stay alert online.")
            break
        if raw.strip().lower() in ("q", "quit", "exit"):
            print("Goodbye! Stay alert online.")
            break
        results = inspect_url(raw)
        print("\nResult:")
        for result in results:
            print("- " + result)
        if results and not results[0].startswith(("No URL entered.", "Could not identify", "This text is not")):
            if not (len(results) == 1 and results[0].startswith("No listed warning")):
                print(f"\nREVIEW CAREFULLY: {len(results)} warning sign(s) found.")
        print("Never enter passwords from unexpected links.")

if __name__ == "__main__":
    main()
